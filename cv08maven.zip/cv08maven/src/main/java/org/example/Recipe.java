package org.example;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Recipe {

    private String name;             // objektová proměnná
    private int preparationTime;     // primitivní proměnná
    private String[] ingredients;    // pole
    private Author author;           // vnořený objekt

    public static void main(String[] args){
        List<Recipe> recipes = provideRecipes();
        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File("c:/JSON/recipies.json"), recipes);

            List<Recipe> nacteneRecepty =
                    mapper.readValue(
                            new File("c:/JSON/recipies.json"),
                            new TypeReference<List<Recipe>>() {}
                    );
            nacteneRecepty.stream().forEach(System.out::println); //vypsani. prevod na stream(proud) a pro kazdy vypsat
        }catch (IOException e){
            throw new RuntimeException(e);
        }

    }

    private static List<Recipe> provideRecipes() {
        List<Recipe> recipes = new ArrayList<>();
        recipes.add(new Recipe(
                "Palačinky",
                25,
                new String[]{"250 ml mléka", "2 vejce", "150 g mouky"},
                new Author("Zdeněk Pohlreich", "Česká republika")));
        recipes.add(new Recipe(
                "Špagety Carbonara",
                30,
                new String[]{"200 g špaget", "100 g slaniny", "2 vejce", "50 g parmazánu"},
                new Author("Gordon Ramsay", "Spojené království")));
        recipes.add(new Recipe(
                "Jablečný závin",
                60,
                new String[]{"500 g listového těsta", "4 jablka", "50 g cukru", "skořice"},
                new Author("Massimo Bottura", "Itálie")));
        return recipes;
    }

    public Recipe(String name,
                  int preparationTime,
                  String[] ingredients,
                  Author author) {
        this.name = name;
        this.preparationTime = preparationTime;
        this.ingredients = ingredients;
        this.author = author;
    }

    public Recipe() { } //jedna varianta, pro jackson, pridam bezparametricky konstruktor a settery, druha je ze jacksonu reknu ze ma pouzit parametricky

    public void setName(String name) {
        this.name = name;
    }

    public void setPreparationTime(int preparationTime) {
        this.preparationTime = preparationTime;
    }

    public void setIngredients(String[] ingredients) {
        this.ingredients = ingredients;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }


    public String getName() {
        return name;
    }

    public int getPreparationTime() {
        return preparationTime;
    }

    public String[] getIngredients() {
        return ingredients;
    }

    public Author getAuthor() {
        return author;
    }


    @Override
    public String toString() {
        return "Recipe{" +
                "name='" + name + '\'' +
                ", preparationTime=" + preparationTime +
                ", ingredients=" + Arrays.toString(ingredients) +
                ", author=" + author +
                '}';
    }
}

class Author {

    private String name;
    private String country;

    public Author() { }

    public Author(String name,
                  String country) {
        this.name = name;
        this.country = country;
    }

    public String getName() {
        return name;
    }

    public String getCountry() {
        return country;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "Author{" +
                "name='" + name + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}

